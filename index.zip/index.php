<!DOCTYPE html>
<html lang="en">
<head>
<title>Rupak's Page</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>
<body>
<form action='' method='post'>
Username
<input type="text" name="usr">
Password
<input type="text" name="pass">
<input type="submit" value="Enter" name="sub">
<h1>My Website</h1>
<p>A website created by me.</p>
</form>
</body>
</html>

<?php
            $msg = '';
            
            if (isset($_POST['sub']) && !empty($_POST['usr']) 
               && !empty($_POST['pass'])) 
	{
		$usr=($_POST['usr']);
		$pass=($_POST['pass']);		
               if ($_POST['usr'] == 'rupak' && 
                  $_POST['pass'] == '1234') 
		{
                  
                  
                  echo 'You have entered valid use name and password';
                }
		
		else {
                  echo 'Wrong username or password';
               }
            }
	else
		{
			echo 'give value';
		}
  ?>